# Zen of Python

#TODO 

- add other languages
- make a doc
